<?php
// Text
$_['text_product_shipping'] = 'Product Shipping';